
  
  const moviesURLs = [
    {title:'ACTION MOVIES',getURL:`discover/tv?api_key=626c79faac7c27563da8ccd8e9e46539&with_genres=28`},
    
    {title:'COMEDY MOVIES',getURL:`discover/tv?api_key=626c79faac7c27563da8ccd8e9e46539&with_genres=35`},
    {title:'CRIME MOVIES',getURL:`discover/tv?api_key=626c79faac7c27563da8ccd8e9e46539&with_genres=80`},

  ]

  export default moviesURLs;