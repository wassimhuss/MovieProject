import React from 'react';
import {connect} from 'react-redux'
const MovieDetails = (props) => {
    console.log(props.data)
    return (
        <div>
            {/* <h1 style={{color:'red'}}>{props.data.movieDetails.movieDetails}</h1> */}
        </div>
    );
};

const mapStateToProps  = (state) => {
    //alert('Data' + state.movies.actionMovies)
   return {data:state}
}
export default connect(mapStateToProps)(MovieDetails)
