import {GET_MOVIE_DETAILS} from '../types'

import moviesURLs from '../../requests/requests'
import axios from '../../axios/Axios'

export const getMovieDetails = (movie_id) => async dispatch => {
    
    try{
        const res = await axios.get(`movie/${movie_id}?api_key=626c79faac7c27563da8ccd8e9e46539&language=en-US`)
        dispatch( {
            type: GET_MOVIE_DETAILS,
            payload:res.data
        })
    }
    catch(e){
        return e
     }
 
 }